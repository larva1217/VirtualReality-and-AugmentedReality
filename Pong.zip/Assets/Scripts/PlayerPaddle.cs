using Unity.Netcode;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerPaddle : NetworkBehaviour
{
    SpriteRenderer _spriteRenderer;
    public float speed = 10f;

    float _inputY;

    void Awake()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
    }

    [ClientRpc]
    public void SetRendererColorClientRpc(Color color)
    {
        _spriteRenderer.color = color;
    }

    [ClientRpc]
    public void SpawnToPositionClientRpc(Vector3 position)
    {
        transform.position = position;
    }

    public void OnMove(InputValue value)
    {
        Vector2 input = value.Get<Vector2>();
        _inputY = input.y;
    }


    void Update()
    {
        if (GameManager.Instance != null && !GameManager.Instance.IsGameActive)
        {
            return;
        }

        if (!IsOwner)
        {
            return;
        }

        

        var distance = _inputY * speed * Time.deltaTime;
        var position = transform.position;
        position.y += distance;

        position.y = Mathf.Clamp(position.y, -4.5f, 4.5f);
        transform.position = position;
    }
}
