using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;


public class Floor : MonoBehaviour
{
    public InputActionReference leftTriggerButton;
    public InputActionReference RightTriggerButton;
    public UnityEngine.XR.Interaction.Toolkit.Interactors.XRRayInteractor leftRay;
    public UnityEngine.XR.Interaction.Toolkit.Interactors.XRRayInteractor rightRay;

    public GameObject voxelFactory;
    public int voxelPoolSize = 20;
    public static List<GameObject> voxelPool = new List<GameObject>();

    public GameObject crosshairPrefab;
    private GameObject leftCrosshair;
    private GameObject rightCrosshair;

    void Start()
    {
        leftTriggerButton.action.started += OnLeftTriggerPressed;
        RightTriggerButton.action.started += OnRightTriggerPressed;
        leftTriggerButton.action.canceled += OnLeftTriggerReleased;
        RightTriggerButton.action.canceled += OnRightTriggerReleased;

        for (int i = 0; i < voxelPoolSize; i++)
        {
            GameObject voxel = Instantiate(voxelFactory);
            voxel.SetActive(false);
            voxelPool.Add(voxel);
        }

        leftCrosshair = Instantiate(crosshairPrefab);
        leftCrosshair.SetActive(false);

        rightCrosshair = Instantiate(crosshairPrefab);
        rightCrosshair.SetActive(false);
    }

    void Update()
    {
        UpdateCrosshair(leftRay, leftTriggerButton, leftCrosshair);
        UpdateCrosshair(rightRay, RightTriggerButton, rightCrosshair);
    }

    void OnLeftTriggerPressed(InputAction.CallbackContext context)
    {
        Debug.Log("Left Trigger Button Pressed!!!");
        Vector3 hitPosition, hitNormal;
        int hitLinePos;
        bool isValid;
        if(leftRay.TryGetHitInfo(out hitPosition, out hitNormal, out hitLinePos, out isValid)){
            Debug.Log("Left hit info " + hitPosition.ToString());
        }
    }

    void OnRightTriggerPressed(InputAction.CallbackContext context)
    {
        Debug.Log("Right Trigger Button Pressed!!!");
        Vector3 hitPosition, hitNormal;
        int hitLinePos;
        bool isValid;
        if(rightRay.TryGetHitInfo(out hitPosition, out hitNormal, out hitLinePos, out isValid)){
            Debug.Log("Right hit info " + hitPosition.ToString());
        }
    }

    void OnLeftTriggerReleased(InputAction.CallbackContext context)
    {
        Debug.Log("Left Trigger Button Released!!!");
        leftCrosshair.SetActive(false);
        SpawnVoxel(rightRay); 
    }

    void OnRightTriggerReleased(InputAction.CallbackContext context)
    {
        Debug.Log("Right Trigger Button Released!!!");
          rightCrosshair.SetActive(false);
        SpawnVoxel(rightRay); 
    }


    void SpawnVoxel(UnityEngine.XR.Interaction.Toolkit.Interactors.XRRayInteractor ray)
    {
        Vector3 hitPosition, hitNormal;
        int hitLinePos;
        bool isValid;

        if (ray.TryGetHitInfo(out hitPosition, out hitNormal, out hitLinePos, out isValid))
        {
            if (voxelPool.Count > 0)
            {
                GameObject voxel = voxelPool[0];
                voxel.SetActive(true);
                voxel.transform.position = hitPosition + new Vector3(0, 0.15f, 0);
                voxelPool.RemoveAt(0);
            }
        }
    }

    void UpdateCrosshair(
        UnityEngine.XR.Interaction.Toolkit.Interactors.XRRayInteractor ray,
        InputActionReference trigger,
        GameObject crosshair)
    {
        if (ray.TryGetHitInfo(out Vector3 hitPosition, out Vector3 hitNormal, out int _, out bool isValid))
        {
            if (trigger.action.ReadValue<float>() > 0.1f)
            {
                crosshair.SetActive(true);
                crosshair.transform.position = hitPosition + hitNormal * 0.01f;

                Vector3 toCamera = crosshair.transform.position - Camera.main.transform.position;
                crosshair.transform.rotation = Quaternion.LookRotation(toCamera);
            }
            else
            {
              crosshair.SetActive(false);
            }
        }
        else
        {
            crosshair.SetActive(false);
        }
    }

}