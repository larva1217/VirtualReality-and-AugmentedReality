using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.ARFoundation;
using UnityEngine.XR.ARSubsystems;
using UnityEngine.EventSystems; 
using UnityEngine.InputSystem; 
public class CarManager : MonoBehaviour
{
    public GameObject indicator;
    public GameObject myCar;
    public float relocationDistance = 1.0f;

    ARRaycastManager arManager;
    GameObject placedObject = null;
    List<ARRaycastHit> hitInfos = new List<ARRaycastHit>();

    
    private CarInputActions carInputActions; 

    void Awake() 
    {
        arManager = GetComponent<ARRaycastManager>();
        carInputActions = new CarInputActions(); 
    }

   
    void OnEnable() 
    {
 
        carInputActions.CarControl.Enable(); 

        carInputActions.CarControl.PlaceCar.performed += OnPlaceCarPerformed;
    }

    
    void OnDisable() 
    {
        carInputActions.CarControl.PlaceCar.performed -= OnPlaceCarPerformed;
        carInputActions.CarControl.Disable(); 
    }

    
    void Start()
    {
        indicator.SetActive(false); 
    }


    void Update()
    {
        DetectGround(); 
    }

  
    private void OnPlaceCarPerformed(InputAction.CallbackContext context)
    {
        if (EventSystem.current.currentSelectedGameObject != null)
        {
            return;
        }

        if (indicator.activeInHierarchy)
        {
            if (placedObject == null)
            {
                placedObject = Instantiate(myCar, indicator.transform.position, indicator.transform.rotation);
            }
            else
            {
                if (Vector3.Distance(placedObject.transform.position, indicator.transform.position) > relocationDistance)
                {
                    placedObject.transform.SetPositionAndRotation(indicator.transform.position, indicator.transform.rotation);
                }
            }
        }
    }


    void DetectGround()
    {
       
        Vector2 screenSize = new Vector2(Screen.width * 0.5f, Screen.height * 0.5f);

     
        if (arManager.Raycast(screenSize, hitInfos, TrackableType.Planes))
        {
            indicator.SetActive(true); 

           
            indicator.transform.position = hitInfos[0].pose.position;
            indicator.transform.rotation = hitInfos[0].pose.rotation;

         
            indicator.transform.position += indicator.transform.up * 0.1f;
        }
    
        else
        {
            indicator.SetActive(false);
        }
    }
}