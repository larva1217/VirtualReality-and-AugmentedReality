using UnityEngine;
using UnityEngine.InputSystem; 

public class CarController : MonoBehaviour
{
    public Material[] carMats;
    public float rotSpeed = 0.1f;
    private CarInputActions carInputActions; 
    void Awake() 
    {
        carInputActions = new CarInputActions(); 
    }


    void OnEnable() 
    {
        carInputActions.CarControl.Enable(); 

        carInputActions.CarControl.Rotate.performed += OnRotatePerformed;
        
        carInputActions.CarControl.Rotate.canceled += OnRotateCanceled;
    }

    void OnDisable() 
    {
        carInputActions.CarControl.Rotate.performed -= OnRotatePerformed;
        carInputActions.CarControl.Rotate.canceled -= OnRotateCanceled;
        carInputActions.CarControl.Disable(); 
    }

    private void OnRotatePerformed(InputAction.CallbackContext context)
    {
        Vector2 delta = context.ReadValue<Vector2>();
        
        transform.Rotate(transform.up, delta.x * -1.0f * rotSpeed);
    }
    
    private void OnRotateCanceled(InputAction.CallbackContext context)
    {
    }

    public void ChangeColor(int num)
    {
        
        transform.Find("Body").gameObject.GetComponent<MeshRenderer>().material = carMats[num];
    }
}